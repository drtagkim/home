// Game Configuration
const canvas = document.getElementById('tetris');
const context = canvas.getContext('2d');
const nextCanvas = document.getElementById('next-canvas');
const nextContext = nextCanvas.getContext('2d');
const holdCanvas = document.getElementById('hold-canvas');
const holdContext = holdCanvas.getContext('2d');

// --- SIZE UPDATE ---
// Block Size = 30px
canvas.width = 360;  // 12 * 30
canvas.height = 600; // 20 * 30

nextCanvas.width = 150;
nextCanvas.height = 150;
holdCanvas.width = 150;
holdCanvas.height = 150;

const SCALE = 30;

context.scale(SCALE, SCALE);
nextContext.scale(SCALE, SCALE);
holdContext.scale(SCALE, SCALE);

// Colors for fallback
const COLORS = [
    null,
    '#FFAB91', // T 
    '#81D4FA', // I 
    '#A5D6A7', // S 
    '#CE93D8', // Z 
    '#FFCC80', // L 
    '#FFF59D', // O 
    '#90CAF9', // J 
];

// Load Sprite Sheet
const spriteSheet = new Image();
spriteSheet.src = 'assets/cat_liquid_sprites.png';

let spriteLoaded = false;
let spriteLayout = 'grid'; // 'grid' or 'strip'

spriteSheet.onload = () => {
    spriteLoaded = true;
    // Auto-detect layout based on aspect ratio
    const ratio = spriteSheet.width / spriteSheet.height;
    if (ratio >= 6) {
        spriteLayout = 'strip'; // Horizontal strip (7x1)
    } else {
        spriteLayout = 'grid'; // Likely 3x3 grid
    }
    console.log(`Sprite loaded. Layout detected: ${spriteLayout}`);
    draw();
};

const PIECES = 'ILJOTSZ';

const arena = createMatrix(12, 20);
const player = {
    pos: { x: 0, y: 0 },
    matrix: null,
    score: 0,
    level: 1,
    lines: 0,
};

let dropCounter = 0;
let dropInterval = 1000;
let lastTime = 0;
let isPaused = false;
let isGameOver = false;
let gameStarted = false;

let nextPiece = null;
let holdPiece = null;
let canHold = true;
let animationId = null;

function createPiece(type) {
    if (type === 'I') {
        return [
            [0, 1, 0, 0],
            [0, 1, 0, 0],
            [0, 1, 0, 0],
            [0, 1, 0, 0],
        ];
    } else if (type === 'L') {
        return [
            [0, 2, 0],
            [0, 2, 0],
            [0, 2, 2],
        ];
    } else if (type === 'J') {
        return [
            [0, 3, 0],
            [0, 3, 0],
            [3, 3, 0],
        ];
    } else if (type === 'O') {
        return [
            [4, 4],
            [4, 4],
        ];
    } else if (type === 'Z') {
        return [
            [5, 5, 0],
            [0, 5, 5],
            [0, 0, 0],
        ];
    } else if (type === 'S') {
        return [
            [0, 6, 6],
            [6, 6, 0],
            [0, 0, 0],
        ];
    } else if (type === 'T') {
        return [
            [0, 7, 0],
            [7, 7, 7],
            [0, 0, 0],
        ];
    }
}

function createMatrix(w, h) {
    const matrix = [];
    while (h--) {
        matrix.push(new Array(w).fill(0));
    }
    return matrix;
}

function collide(arena, player) {
    const [m, o] = [player.matrix, player.pos];
    for (let y = 0; y < m.length; ++y) {
        for (let x = 0; x < m[y].length; ++x) {
            if (m[y][x] !== 0 &&
                (arena[y + o.y] && arena[y + o.y][x + o.x]) !== 0) {
                return true;
            }
        }
    }
    return false;
}

function drawBlock(ctx, x, y, value) {
    if (value === 0) return;

    if (spriteLoaded) {
        let sx, sy, sw, sh;

        if (spriteLayout === 'strip') {
            sw = spriteSheet.width / 7;
            sh = spriteSheet.height;
            sx = (value - 1) * sw;
            sy = 0;
        } else {
            // Assume 3x3 Grid
            // value 1..7
            // col = (value-1) % 3
            // row = floor((value-1) / 3)
            const cols = 3;
            const rows = 3;
            sw = spriteSheet.width / cols;
            sh = spriteSheet.height / rows;
            const index = value - 1;
            const col = index % cols;
            const row = Math.floor(index / cols);
            sx = col * sw;
            sy = row * sh;
        }

        ctx.drawImage(spriteSheet, sx, sy, sw, sh, x, y, 1, 1);
    } else {
        // Fallback
        ctx.fillStyle = COLORS[value];
        ctx.fillRect(x, y, 1, 1);
        ctx.lineWidth = 0.05;
        ctx.strokeStyle = '#fff';
        ctx.strokeRect(x, y, 1, 1);

        ctx.fillStyle = '#fff';
        ctx.beginPath();
        ctx.arc(x + 0.3, y + 0.3, 0.1, 0, Math.PI * 2);
        ctx.arc(x + 0.7, y + 0.3, 0.1, 0, Math.PI * 2);
        ctx.fill();
    }
}

function drawMatrix(matrix, offset, ctx = context) {
    matrix.forEach((row, y) => {
        row.forEach((value, x) => {
            if (value !== 0) {
                drawBlock(ctx, x + offset.x, y + offset.y, value);
            }
        });
    });
}

function draw() {
    context.clearRect(0, 0, canvas.width, canvas.height);

    // Slight transparency for board
    context.fillStyle = 'rgba(255, 243, 224, 0.2)';
    context.fillRect(0, 0, canvas.width, canvas.height);

    drawMatrix(arena, { x: 0, y: 0 });

    if (!isGameOver && !isPaused && gameStarted) {
        const ghostPos = { ...player.pos };
        while (!collide(arena, { pos: ghostPos, matrix: player.matrix })) {
            ghostPos.y++;
        }
        ghostPos.y--;

        context.globalAlpha = 0.3;
        drawMatrix(player.matrix, ghostPos);
        context.globalAlpha = 1;
    }

    if (player.matrix) {
        drawMatrix(player.matrix, player.pos);
    }
}

function drawNext() {
    nextContext.clearRect(0, 0, nextCanvas.width, nextCanvas.height);
    if (nextPiece) {
        const offsetX = (5 - nextPiece[0].length) / 2;
        const offsetY = (5 - nextPiece.length) / 2;
        drawMatrix(nextPiece, { x: offsetX, y: offsetY }, nextContext);
    }
}

function drawHold() {
    holdContext.clearRect(0, 0, holdCanvas.width, holdCanvas.height);
    if (holdPiece) {
        const offsetX = (5 - holdPiece[0].length) / 2;
        const offsetY = (5 - holdPiece.length) / 2;
        drawMatrix(holdPiece, { x: offsetX, y: offsetY }, holdContext);
    }
}

function merge(arena, player) {
    player.matrix.forEach((row, y) => {
        row.forEach((value, x) => {
            if (value !== 0) {
                arena[y + player.pos.y][x + player.pos.x] = value;
            }
        });
    });
}

function playerDrop() {
    player.pos.y++;
    if (collide(arena, player)) {
        player.pos.y--;
        merge(arena, player);
        playerReset();
        arenaSweep();
        updateScore();
        canHold = true;
    }
    dropCounter = 0;
}

function playerHardDrop() {
    while (!collide(arena, player)) {
        player.pos.y++;
    }
    player.pos.y--;
    merge(arena, player);
    playerReset();
    arenaSweep();
    updateScore();
    canHold = true;
    dropCounter = 0;
}

function playerMove(dir) {
    player.pos.x += dir;
    if (collide(arena, player)) {
        player.pos.x -= dir;
    }
}

function playerRotate(dir) {
    const pos = player.pos.x;
    let offset = 1;
    rotate(player.matrix, dir);
    while (collide(arena, player)) {
        player.pos.x += offset;
        offset = -(offset + (offset > 0 ? 1 : -1));
        if (offset > player.matrix[0].length) {
            rotate(player.matrix, -dir);
            player.pos.x = pos;
            return;
        }
    }
}

function rotate(matrix, dir) {
    for (let y = 0; y < matrix.length; ++y) {
        for (let x = 0; x < y; ++x) {
            [
                matrix[x][y],
                matrix[y][x],
            ] = [
                    matrix[y][x],
                    matrix[x][y],
                ];
        }
    }
    if (dir > 0) {
        matrix.forEach(row => row.reverse());
    } else {
        matrix.reverse();
    }
}

function playerReset() {
    if (nextPiece === null) nextPiece = createPiece(PIECES[PIECES.length * Math.random() | 0]);

    player.matrix = nextPiece;
    nextPiece = createPiece(PIECES[PIECES.length * Math.random() | 0]);
    drawNext();

    player.pos.y = 0;
    player.pos.x = (arena[0].length / 2 | 0) -
        (player.matrix[0].length / 2 | 0);

    if (collide(arena, player)) {
        gameOver();
    }
}

function playerHold() {
    if (!canHold || !gameStarted || isPaused) return;

    if (holdPiece === null) {
        holdPiece = player.matrix;
        playerReset();
    } else {
        const temp = player.matrix;
        player.matrix = holdPiece;
        holdPiece = temp;
        player.pos.y = 0;
        player.pos.x = (arena[0].length / 2 | 0) - (player.matrix[0].length / 2 | 0);
    }

    canHold = false;
    drawHold();
    drawNext();
}

function arenaSweep() {
    let rowCount = 0;
    outer: for (let y = arena.length - 1; y > 0; --y) {
        for (let x = 0; x < arena[y].length; ++x) {
            if (arena[y][x] === 0) {
                continue outer;
            }
        }

        const row = arena.splice(y, 1)[0].fill(0);
        arena.unshift(row);
        ++y;

        rowCount++;
    }

    if (rowCount > 0) {
        const points = [0, 100, 300, 500, 800];
        player.score += points[rowCount] * player.level;
        player.lines += rowCount;
        player.level = Math.floor(player.lines / 10) + 1;
        dropInterval = Math.max(100, 1000 - (player.level - 1) * 100);
    }
}

function updateScore() {
    document.getElementById('score').innerText = player.score;
    document.getElementById('level').innerText = player.level;
    document.getElementById('lines').innerText = player.lines;
}

function gameOver() {
    isGameOver = true;
    gameStarted = false;
    document.getElementById('game-over').classList.remove('hidden');
    document.getElementById('final-score').innerText = player.score;
    cancelAnimationFrame(animationId);
}

function startGame() {
    if (gameStarted) return;

    document.getElementById('game-start').classList.add('hidden');
    document.getElementById('game-over').classList.add('hidden');

    arena.forEach(row => row.fill(0));
    player.score = 0;
    player.lines = 0;
    player.level = 1;
    dropInterval = 1000;
    isGameOver = false;
    isPaused = false;
    gameStarted = true;
    nextPiece = null;
    holdPiece = null;
    canHold = true;

    updateScore();
    drawHold();

    playerReset();
    update();
}

function resetGame() {
    startGame();
}

function update(time = 0) {
    if (isPaused || isGameOver || !gameStarted) return;

    const deltaTime = time - lastTime;
    lastTime = time;

    dropCounter += deltaTime;
    if (dropCounter > dropInterval) {
        playerDrop();
    }

    draw();
    animationId = requestAnimationFrame(update);
}

document.addEventListener('keydown', event => {
    if ([32, 37, 38, 39, 40].indexOf(event.keyCode) > -1) {
        event.preventDefault();
    }

    if (!gameStarted) return;
    if (isGameOver) return;

    if (event.keyCode === 80) {
        togglePause();
    }

    if (isPaused) return;

    if (event.keyCode === 37) {
        playerMove(-1);
    } else if (event.keyCode === 39) {
        playerMove(1);
    } else if (event.keyCode === 40) {
        playerDrop();
    } else if (event.keyCode === 38) { // Rotate
        playerRotate(1);
    } else if (event.keyCode === 32) { // Hard Drop
        playerHardDrop();
    } else if (event.keyCode === 67) { // Hold
        playerHold();
    }
});

function togglePause() {
    if (isGameOver || !gameStarted) return;
    isPaused = !isPaused;

    const pauseScreen = document.getElementById('pause-screen');
    if (isPaused) {
        pauseScreen.classList.remove('hidden');
        cancelAnimationFrame(animationId);
    } else {
        pauseScreen.classList.add('hidden');
        lastTime = performance.now();
        update();
    }
}

document.getElementById('start-btn').addEventListener('click', startGame);
document.getElementById('restart-btn').addEventListener('click', resetGame);
document.getElementById('resume-btn').addEventListener('click', togglePause);
document.getElementById('lang-btn').addEventListener('click', toggleLanguage);

updateText();
draw();
